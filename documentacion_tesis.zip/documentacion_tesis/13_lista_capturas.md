# Lista de capturas de evidencia

**Estado:** Las imágenes **NO fueron generadas automáticamente** en este entorno (sin captura de navegador).  
Carpeta destino: `documentacion_tesis/capturas/`  
Instrucciones detalladas también en `capturas/LISTA_CAPTURAS_PENDIENTES.md`.

---

## Pantallas funcionales

| Archivo | Dónde entrar | Usuario | Qué hacer | Qué debe verse | Qué demuestra |
|---------|--------------|---------|-----------|----------------|---------------|
| 01_login.png | http://localhost:5173/login | — | Abrir URL | Formulario usuario/contraseña, logo municipal | Punto de acceso seguro |
| 02_dashboard.png | /dashboard | admin o alcalde | Login → Dashboard | Tarjetas KPI, tablas resumen | Módulo reportes ejecutivos |
| 03_dashboard_filtro.png | /dashboard | admin | Cambiar rango fechas si UI lo permite | Variación de métricas | Datos dinámicos API |
| 04_peticiones.png | /peticiones | recepcion | Menú Peticiones | Tabla con códigos y estados | Listado central |
| 05_peticiones_filtro.png | /peticiones | recepcion | Filtrar estado RECIBIDA | Listado filtrado | Consultas con parámetros |
| 06_registrar_peticion.png | /peticiones/nueva | recepcion | Llenar formulario | Campos ciudadano + petición | Registro integrado |
| 07_detalle_peticion.png | /peticiones/:id | cualquier rol con acceso | Clic en fila | Datos completos petición | Trazabilidad |
| 08_seguimiento.png | detalle | alcalde o jefe | Cambiar estado + comentario | Formulario estado | Control de ciclo de vida |
| 09_historial.png | detalle | recepcion | Scroll historial | Lista cronológica movimientos | Bitácora Seguimiento |
| 10_usuarios_admin.png | /usuarios | admin | Menú Usuarios | Tabla usuarios/roles | Administración |
| 11_nuevo_usuario.png | /usuarios | admin | Crear usuario | Modal/form alta | RBAC |
| 12_vista_recepcion.png | /peticiones | recepcion | Tras login | Sin dashboard en menú | Restricción UI |
| 13_vista_jefe_departamento.png | /peticiones | jefe_obras | Tras login | Solo peticiones de Obras | Aislamiento departamental |
| 14_vista_alcalde.png | /dashboard | alcalde | Tras login | Dashboard + menú peticiones | Rol autoridad |

---

## Evidencia técnica

| Archivo | Cómo obtenerla | Qué demuestra |
|---------|----------------|---------------|
| 15_pruebas_terminal.png | Terminal con `node documentacion_tesis/ejecutar_pruebas_tesis.js` | 18/18 PASS |
| 16_sql_peticion.png | SSMS: consulta #2 en `consultas_evidencia.sql` | Datos en Peticion |
| 17_sql_ciudadano.png | SSMS: consulta #1 | Entidad Ciudadano |
| 18_sql_usuario.png | SSMS: consulta #5 | Roles Usuario |
| 19_sql_seguimiento.png | SSMS: consulta #6 | Historial SQL |
| 20_sql_relaciones.png | SSMS: consulta FK al final | Integridad referencial |

---

## Comandos previos

```powershell
cd backend-muni && npm.cmd start
cd frontend-react && npm.cmd run dev
```
