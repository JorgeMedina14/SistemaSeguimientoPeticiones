# Seguridad — modelo CIA

## CONFIDENCIALIDAD

| Aspecto | Implementación |
|---------|----------------|
| Login | `POST /auth/login`, mensajes genéricos “Credenciales inválidas” |
| Contraseñas | bcrypt hash; no se devuelven en API |
| Roles | JWT payload + middleware `authorizeRoles` |
| Rutas protegidas | `authenticateJWT` en rutas sensibles |
| Información sensible | DPI en BD; transmisión HTTPS **NO DETERMINADA** en local (HTTP) |

## INTEGRIDAD

| Aspecto | Implementación |
|---------|----------------|
| Validaciones API | services (DPI, estados, roles, campos requeridos) |
| PK / FK / CHECK | SQL Server — `DATABASE.md` |
| Duplicados | UNIQUE username, DPI, código petición; lógica alcalde único |
| Transacciones | `withTransaction` en crear petición y cambio estado |
| SQL Injection | parámetros `@` en repositorios |

## DISPONIBILIDAD

| Aspecto | Implementación |
|---------|----------------|
| Errores | handlers Express 404/500 |
| Conexión BD | pool + reintento `withPool` |
| Recuperación | reconexión automática una vez |
| Respaldos | **NO IMPLEMENTADO** en código |
| Dependencia red | frontend requiere API disponible |

---

## Tabla de riesgos

| Riesgo | CIA | Protección implementada | Evidencia en código | Riesgo residual |
|--------|-----|-------------------------|---------------------|-----------------|
| Robo de credenciales en tránsito | C | JWT; HTTPS en prod documentado Railway | `auth.service.js`, `RAILWAY.md` | Alto en HTTP local |
| SQL Injection | I | Consultas parametrizadas | `peticiones.repository.js` | Bajo |
| Escalada de privilegios | C/I | JWT + `authorizeRoles` + filtros JEFE | `role.middleware.js`, `peticiones.service.js` | Medio si token filtrado |
| Contraseñas en texto plano | C | bcrypt | `usuarios.service.js` | Bajo |
| Token sin revocación | C | Expiración JWT | `JWT_EXPIRES_IN` | Medio (token válido hasta expirar) |
| Usuario inactivo accede | C/I | Flag `Activo` en login | `auth.service.js` | Bajo |
| Pérdida de BD | D | NO IMPLEMENTADO backup app | — | Alto (operativo municipal) |
| Caída SQL Server | D | Errores 500; pool reconecta | `pool.js` | Medio |
| DPI expuesto en UI | C | Solo usuarios autenticados | rutas protegidas | Medio según política municipal |
| Eliminación petición | I | DELETE solo ADMIN/ALCALDE | `peticiones.routes.js` | Medio (sin soft-delete) |
