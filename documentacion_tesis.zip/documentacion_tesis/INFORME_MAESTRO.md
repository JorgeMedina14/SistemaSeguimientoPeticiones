# INFORME MAESTRO — Trabajo de Graduación

**Título del proyecto de software:**  
Sistema Web para el Registro, Control y Seguimiento de Peticiones Ciudadanas en una Municipalidad

**Repositorio:** `PG_Muni`  
**Fecha de documentación:** 2026-10-15  
**Alcance de este informe:** Consolidación de evidencia técnica **sin modificar el sistema**.

---

## 1. Resumen ejecutivo

El sistema implementado es una **SPA React (Vite)** que consume una **API REST Node.js/Express**, persistiendo en **SQL Server** (`MuniPeticionesJalapa`). Soporta **cuatro roles**, registro de peticiones con **código único**, **seguimiento de estados**, administración de usuarios (ADMIN) y **dashboard** para ADMIN/ALCALDE.

**Despliegue:** documentación opcional Railway (`RAILWAY.md`); evidencia de pruebas obtenida en **entorno local**. No se verifica URL pública activa en el código.

---

## 2. Índice de entregables (`documentacion_tesis/`)

| # | Archivo | Contenido |
|---|---------|-----------|
| 01 | `01_auditoria_proyecto.md` | 20 puntos de auditoría técnica |
| 02 | `02_instalacion_software_funcional.md` | Instalación en PC nueva |
| 03 | `03_arquitectura.md` | Capas cliente-servidor |
| 04 | `04_funcionalidades.md` | Módulos reales |
| 05 | `05_roles_permisos.md` | Matriz RBAC |
| 06 | `06_seguridad_CIA.md` | Confidencialidad, integridad, disponibilidad |
| 07 | `07_pruebas.md` | Plan y scripts |
| 08 | `08_resultados_pruebas.md` | **18 PASS / 0 FAIL** + e2e-roles OK |
| 09 | `09_base_datos.md` | Resumen BD (+ `DATABASE.md`) |
| 10 | `10_codigo_para_anexos.md` | Fragmentos para anexos |
| 11 | `11_proceso_actual_nuevo.md` | AS-IS / TO-BE |
| 12 | `12_manual_usuario.md` | Manual por rol |
| 13 | `13_lista_capturas.md` | Guía de screenshots |
| — | `datos_prueba.sql` | Datos sintéticos |
| — | `consultas_evidencia.sql` | SELECT evidencia SSMS |
| — | `ejecutar_pruebas_tesis.js` | Automatización 18 casos |
| — | `resultados_pruebas.json` | Resultado machine-readable |
| — | `salida_pruebas_terminal.txt`, `salida_e2e_roles.txt` | Logs |
| — | `capturas/` | **Pendiente** llenar PNGs |

---

## 3. Stack tecnológico (verificado)

| Capa | Tecnología |
|------|------------|
| Frontend | React 19, Vite 8, React Router 7, Axios |
| Backend | Node.js 20 (Dockerfile), Express 4 |
| BD | SQL Server Express `localhost\SQLEXPRESS` |
| Auth | JWT + bcrypt |
| Docs API | Swagger `/api-docs` |

---

## 4. Puertos y URLs locales

- Frontend dev: **5173**
- Backend: **5000**
- BD: **MuniPeticionesJalapa**

---

## 5. Resultados de pruebas (resumen)

| Suite | Total | PASS | FAIL |
|-------|-------|------|------|
| `ejecutar_pruebas_tesis.js` | 18 | 18 | 0 |
| `npm run test:roles` | múltiples por 6 usuarios | OK | 0 |

Detalle: `08_resultados_pruebas.md`.

---

## 6. Base de datos

- **6 tablas**, sin SP/vistas.
- Relaciones FK documentadas.
- Scripts: importación (`DATABASE.md`), evidencia y datos sintéticos en esta carpeta.

---

## 7. Seguridad (síntesis)

- Contraseñas: **bcrypt**.
- Autorización: **JWT + roles** (API y React).
- SQL: **consultas parametrizadas**.
- Riesgos residuales: HTTP local, sin backup automatizado, sin revocación JWT — ver `06_seguridad_CIA.md`.

---

## 8. Proceso de negocio

- **Actual:** manual, disperso, sin trazabilidad central (`11_proceso_actual_nuevo.md`).
- **Nuevo:** flujo web con código, estados, seguimiento, dashboard (`11_proceso_actual_nuevo.md`).

---

## 9. Lo NO implementado (explícito)

- Módulo independiente de ciudadanos (solo vía alta de petición).
- Notificaciones automáticas al ciudadano.
- Pruebas unitarias Jest/Mocha.
- Respaldos automáticos de BD en la aplicación.
- Capturas PNG (pendientes de tomar manualmente).
- Despliegue web verificado en producción.

---

## 10. Pasos recomendados antes de la defensa

1. Ejecutar `datos_prueba.sql` si se requiere más volumen de datos.
2. Tomar capturas según `13_lista_capturas.md`.
3. Ejecutar SSMS con `consultas_evidencia.sql` (capturas 16–20).
4. Re-ejecutar pruebas y guardar screenshot terminal.
5. Incorporar secciones de este informe al capítulo de implementación, pruebas y manual de usuario de la tesis.

---

## 11. Referencias en el repositorio

- `README.md` — visión general y credenciales de prueba.
- `DATABASE.md` — modelo de datos.
- `POSTMAN_GUIA.txt` — pruebas API manuales.
- `RAILWAY.md` — despliegue opcional.

---

*Documento generado a partir del análisis del código fuente existente. No sustituye la redacción académica del estudiante; provee insumos técnicos verificables.*
