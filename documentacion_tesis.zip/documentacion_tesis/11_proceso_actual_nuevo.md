# 4.3.6 Modelado del proceso actual (AS-IS)

Texto formal basado en el problema que el sistema documenta resolver (`README.md`, alcance del proyecto). **No describe software** sino la práctica manual/dispersa previa inferida del dominio municipal.

## Descripción del proceso actual

1. **Recepción de la petición.** El ciudadano presenta su solicitud de forma presencial, telefónica o por canales informales. La información llega sin un formato único estandarizado.

2. **Registro manual y disperso.** La recepción anota datos en cuadernos, hojas sueltas o archivos no centralizados. No existe un código único transversal que identifique la petición en todas las áreas.

3. **Identificación del responsable.** El personal determina manualmente qué dependencia municipal podría atender el caso, con criterios poco formalizados y dependientes del criterio individual.

4. **Traslado de la información.** La petición se comunica por medios físicos o mensajes (copias, llamadas, correos) hacia el departamento supuestamente competente, generando demoras y pérdida de contexto.

5. **Atención por el departamento.** El área técnica o administrativa registra la solicitud en sus propios controles (si existen) sin integración con otros departamentos.

6. **Seguimiento limitado.** El ciudadano debe volver a consultar para conocer avances; no hay historial unificado de cambios de estado accesible institucionalmente.

7. **Decisión de resolución.** La resolución se comunica de forma heterogénea; no siempre queda constancia formal del cierre.

8. **Cierre.** El expediente puede quedar incompleto o archivado sin trazabilidad central.

## Problemas detectados (alineados al objetivo del sistema)

- Falta de trazabilidad y código único.
- Duplicidad de registros y riesgo de pérdida de información.
- Dificultad para medir tiempos, pendientes y resueltas.
- Control de acceso inexistente por rol.
- Seguimiento ciudadano deficiente.

---

# 4.3.7 Modelado del nuevo proceso (TO-BE)

Texto alineado **únicamente** a funcionalidades implementadas en el sistema web.

## Actores

- **Ciudadano** (registrado en BD como entidad `Ciudadano`, vinculado a peticiones).
- **Recepción / Alcalde** (registro de peticiones — roles `RECEPCION`, `ALCALDE`).
- **Departamento responsable** (asignación vía `IdDepartamento`).
- **Jefe de departamento** (seguimiento y cambio de estado en su área — `JEFE_DEPTO`).
- **Autoridad municipal / Administrador** (dashboard, reportes, usuarios — `ALCALDE`, `ADMIN`).

## Flujo del nuevo proceso

1. **Ciudadano** presenta su petición ante la municipalidad.

2. **Recepción (o Alcalde)** accede al sistema web (`/login`), autenticación JWT.

3. **Registro en sistema web** (`/peticiones/nueva` → `POST /peticiones`):
   - Validación de DPI (13 dígitos) o reutilización de ciudadano existente.
   - Asignación a **departamento responsable**.
   - Generación de **código único** (`JAL-AAAA-NNNNNN`).
   - Estado inicial **RECIBIDA** y primer registro en **Seguimiento**.

4. **Consulta y filtros** por personal autorizado (`/peticiones` — estado, prioridad, búsqueda).

5. **Atención departamental:** petición visible según rol; jefe de departamento solo ve peticiones de su departamento.

6. **Gestión de estados:** `EN_REVISION`, `ASIGNADA`, `EN_PROCESO`, etc., mediante `PUT /peticiones/:id/estado`, con comentario opcional y nuevo registro en **Seguimiento** (historial).

7. **Decisión: ¿petición resuelta?**
   - **NO:** permanece en estados intermedios; el ciclo continúa con seguimientos y cambios de estado.
   - **SÍ:** se marca **RESUELTA** (o **RECHAZADA** / **CERRADA** según corresponda); el sistema puede registrar `FechaCierre` en estados finales (lógica en repositorio).

8. **Información al ciudadano:** **NO IMPLEMENTADO** módulo de notificaciones automáticas (correo/SMS); la comunicación externa queda fuera del sistema.

9. **Cierre institucional:** estado **CERRADA** cuando aplique; historial completo consultable en detalle de petición.

10. **Dashboard y reportes** (`/dashboard`, `/reportes/*`): indicadores de totales, resueltas, pendientes, por departamento y actividad reciente para **ADMIN** y **ALCALDE**.

## Mejoras respecto al proceso actual (demostrables)

- Código único y centralización en SQL Server.
- Historial de seguimiento auditable.
- Control de acceso por roles.
- Métricas en dashboard.
- Integridad referencial (FK) y validaciones.
