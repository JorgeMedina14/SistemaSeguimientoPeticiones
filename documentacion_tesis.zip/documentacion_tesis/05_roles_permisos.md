# Fase 4 — Roles y permisos

## Roles reales

| Rol | Descripción operativa (según código) |
|-----|--------------------------------------|
| **ADMIN** | Administración de usuarios; acceso total a peticiones y dashboard; diagnóstico BD |
| **ALCALDE** | Dashboard, crear y gestionar peticiones, eliminar peticiones |
| **RECEPCION** | Registrar y consultar peticiones; catálogo departamentos |
| **JEFE_DEPTO** | Consultar y actualizar estado solo de peticiones de su `IdDepartamento` |

---

## Matriz de acceso

### Frontend (menú y rutas)

| Módulo / ruta | ADMIN | ALCALDE | RECEPCION | JEFE_DEPTO |
|---------------|-------|---------|-----------|------------|
| Dashboard | Sí | Sí | No (redirige) | No |
| Peticiones | Sí | Sí | Sí | Sí |
| Nueva petición | No* | Sí | Sí | No |
| Detalle petición | Sí | Sí | Sí | Sí |
| Usuarios | Sí | No | No | No |

\* Menú no incluye “Nueva petición” para ADMIN (`getMenuItems` en `roles.js`); API tampoco autoriza `POST /peticiones` para ADMIN.

### Backend (endpoints críticos)

Ver tabla completa en `01_auditoria_proyecto.md` sección 10.

---

## Acciones restringidas (ejemplos verificados)

- RECEPCION → `GET /usuarios` → **403**
- JEFE_DEPTO → `POST /peticiones` → **403**
- JEFE_DEPTO → `GET /departamentos` → **403**
- Petición de otro departamento → **403** en detalle/cambio estado
- Usuario inactivo → login **403** (`auth.service.js`)

---

## Evidencia automatizada

Script existente: `backend-muni/scripts/e2e-roles.js`  
Salida de ejecución local: `documentacion_tesis/salida_e2e_roles.txt`
