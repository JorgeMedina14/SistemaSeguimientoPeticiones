# Fase 3 — Arquitectura del sistema

## Vista general

```text
[Navegador]
    │ HTTP (React SPA)
    ▼
[Vite dev :5173] ──Axios──► [Express API :5000]
                                  │
                                  ├── JWT (auth/authorize)
                                  ├── Controllers
                                  ├── Services (reglas de negocio)
                                  ├── Repositories (SQL parametrizado)
                                  └── mssql / msnodesqlv8
                                        │
                                        ▼
                              [SQL Server Express]
                              BD: MuniPeticionesJalapa
```

## Capas backend

| Capa | Responsabilidad | Ubicación |
|------|-----------------|-----------|
| Rutas | HTTP, middleware auth/roles | `src/routes/*.routes.js` |
| Controladores | Request/response JSON | `src/controllers/` |
| Servicios | Validaciones, transacciones | `src/services/` |
| Repositorios | Acceso a datos | `src/repositories/` |
| Infraestructura BD | Pool, reconexión | `src/db/pool.js`, `src/config/db.js` |

## Capas frontend

| Capa | Ubicación |
|------|-----------|
| Páginas | `src/pages/` |
| Componentes UI/layout | `src/components/` |
| Cliente HTTP | `src/api/` |
| Estado auth | `src/context/AuthContext.jsx` |
| Control de acceso UI | `src/routes/ProtectedRoute.jsx`, `src/utils/roles.js` |

## Modo producción (Docker / Railway)

- Build frontend → `frontend-react/dist`
- Backend sirve estáticos + API (`app.js`, `FRONTEND_DIST`)
- Una sola URL pública (documentado en `RAILWAY.md`, no verificado en este informe)

## Decisiones de diseño documentadas en README

- Estados y roles como `varchar` + CHECK (sin tablas catálogo separadas)
- Seguimiento en tabla `Seguimiento` (historial de estados)
- Códigos de petición: `JAL-AAAA-NNNNNN` vía `SecuenciaCodigo`
