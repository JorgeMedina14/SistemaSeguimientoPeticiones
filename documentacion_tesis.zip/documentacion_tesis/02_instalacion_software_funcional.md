# Fase 2 — Software funcional e instalación

## Estado de despliegue

**SISTEMA EJECUTADO EN ENTORNO LOCAL** (desarrollo académico).

El repositorio incluye guía **opcional** de publicación en Railway (`RAILWAY.md`, `Dockerfile`, `railway.toml`), pero **no hay URL de producción verificada** en el código (solo placeholders). No se documenta un despliegue web activo como evidencia de esta tesis salvo que el estudiante lo haya configurado por cuenta propia.

---

## Escenario: computadora nueva en la Municipalidad

### 1. Requisitos de hardware recomendados

| Componente | Mínimo razonable (local) |
|------------|-------------------------|
| CPU | 4 núcleos |
| RAM | 8 GB (16 GB recomendado con SSMS + IDE) |
| Disco | 10 GB libres (SQL Server + Node + repo) |
| Red | Localhost; internet solo para `npm install` |

*Valores orientativos; NO DETERMINADOS en documentación oficial del proyecto.*

### 2. Sistema operativo

- **Windows 10/11** (evidencia: conexión `msnodesqlv8`, ODBC, `README.md` con PowerShell)
- Linux/macOS: **NO DETERMINADO** como entorno soportado oficialmente en este repo

### 3. Versión de Node.js

- `Dockerfile`: **Node 20** (`node:20-bookworm-slim`)
- `package.json`: no declara campo `engines`
- Instalación local: Node **LTS 20.x o superior** compatible con Vite 8 / React 19

### 4. Gestor de paquetes

- **npm** (`npm.cmd install`, `npm start`, `npm run dev`)

### 5. SQL Server requerido

- **SQL Server Express** (documentado: `localhost\SQLEXPRESS`)
- Compatibilidad BD: nivel 160 (SQL Server 2022) según `DATABASE.md`

### 6. SQL Server Management Studio

- **Recomendado** para importar script y ejecutar consultas de evidencia (`DATABASE.md`, `consultas_evidencia.sql`)

### 7. Nombre real de la base de datos

- **`MuniPeticionesJalapa`**

### 8. Crear / restaurar la base de datos

1. Abrir SSMS → conectar a `localhost\SQLEXPRESS` (Windows Authentication).
2. Ejecutar script completo `bdmUNI_importar_SSMS.sql` (elimina y recrea la BD si existe — ver advertencia en `DATABASE.md`).
3. Opcional datos sintéticos: `documentacion_tesis/datos_prueba.sql`.
4. Opcional jefes de departamento: `npm run seed:jefes` en `backend-muni`.

### 9. Variables de entorno necesarias

Copiar `backend-muni/.env.example` → `backend-muni/.env`:

```env
NODE_ENV=development
PORT=5000
DB_SERVER=localhost\SQLEXPRESS
DB_DATABASE=MuniPeticionesJalapa
DB_TRUSTED_CONNECTION=true
JWT_SECRET=<clave_secreta_larga>
JWT_EXPIRES_IN=8h
```

**No incluir contraseñas SQL** en entorno local con Windows Auth.

Frontend (opcional en dev):

```env
VITE_API_URL=http://localhost:5000
```

(`frontend-react/README.md`)

### 10. Cadena de conexión (sin contraseñas)

**Local — Windows Authentication:**

```text
Driver={ODBC Driver 17 for SQL Server};Server=localhost\SQLEXPRESS;Database=MuniPeticionesJalapa;Trusted_Connection=Yes;TrustServerCertificate=Yes;
```

Equivalente lógico en `backend-muni/src/config/db.js` (`connectionString`).

**Nube (Railway):** usuario SQL — ver `RAILWAY.md` (variables `DB_USER`, `DB_PASSWORD`; no documentar valores reales).

### 11. Instalar dependencias backend

```powershell
cd PG_Muni\backend-muni
npm.cmd install
```

Dependencia opcional Windows: `msnodesqlv8` (para Trusted Connection).

### 12. Comando REAL para iniciar backend

```powershell
npm.cmd start
```

(`node src/server.js`)

### 13. Puerto REAL del backend

- **5000** (`PORT` o default en `server.js`)

### 14. Instalar dependencias frontend

```powershell
cd PG_Muni\frontend-react
npm.cmd install
```

### 15. Comando REAL para iniciar frontend

```powershell
npm.cmd run dev
```

### 16. Puerto REAL del frontend (desarrollo)

- **5173** (`frontend-react/vite.config.js`)

### 17. URL local de acceso

| Servicio | URL |
|----------|-----|
| Frontend (dev) | http://localhost:5173 |
| Backend API | http://localhost:5000 |
| Swagger | http://localhost:5000/api-docs |
| Health | http://localhost:5000/health |

### 18. Verificar conexión SQL Server

1. `GET http://localhost:5000/health` → debe responder OK.
2. Login como `admin` → `GET http://localhost:5000/db/ping` con Bearer token (solo ADMIN).
3. Alternativa SSMS: ejecutar `SELECT 1` en `MuniPeticionesJalapa`.
4. Alternativa terminal: `sqlcmd -S localhost\SQLEXPRESS -E -Q "SELECT COUNT(*) FROM MuniPeticionesJalapa.dbo.Peticion"`.

### 19. Cómo iniciar sesión

1. Abrir http://localhost:5173/login  
2. Usuarios de prueba (`README.md`):  
   - `admin` / `admin123`  
   - `alcalde` / `alcalde123`  
   - `recepcion` / `recepcion123`  
   - jefes: `jefe_obras`, `jefe_jalapagua`, `jefe_electrica` / `jefe123`

### 20. Si algo no responde

| Síntoma | Acción |
|---------|--------|
| Backend no inicia | Verificar Node, `npm install`, `JWT_SECRET` en `.env`, puerto 5000 libre |
| Error SQL / login API | Servicio `MSSQL$SQLEXPRESS` en ejecución; BD importada; permisos Windows del usuario que ejecuta Node |
| Frontend vacío / CORS | Backend en 5000; `VITE_API_URL` correcto |
| 401 en API | Token expirado; volver a login |
| 403 | Rol sin permiso (comportamiento esperado) |
| `/db/ping` 401/403 | Requiere ADMIN autenticado |

**Respaldos automáticos:** NO IMPLEMENTADO en el proyecto.
