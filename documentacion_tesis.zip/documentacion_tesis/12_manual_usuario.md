# Manual de usuario — Sistema de Peticiones Ciudadanas

**Acceso local:** http://localhost:5173 (frontend en desarrollo)  
**Requisito:** backend en http://localhost:5000

---

## 1. Administrador (ADMIN)

### Inicio de sesión
1. Abrir `/login`.
2. Usuario: `admin` — contraseña: `admin123` (datos de prueba del README).
3. Tras login, redirección a **Dashboard**.

### Navegación
Menú lateral: Dashboard, Peticiones, Usuarios.

### Acciones principales
- **Dashboard:** revisar totales, % resueltas/pendientes, tablas por estado/departamento, últimos movimientos.
- **Peticiones:** listar, buscar (`q`), filtrar por estado y prioridad, abrir detalle.
- **Detalle:** ver historial; cambiar estado (si aplica); eliminar petición (API — verificar si botón visible en UI).
- **Usuarios:** crear usuario, editar, activar/desactivar, cambiar contraseña, eliminar (no la propia cuenta).

### Cierre de sesión
Usar opción de cerrar sesión en la interfaz (Header/Sidebar — según `MainLayout`).

---

## 2. Recepción (RECEPCION)

### Inicio de sesión
`recepcion` / `recepcion123` → redirección a **Peticiones** (sin dashboard).

### Acciones principales
- **Peticiones:** consultar listado y filtros.
- **Nueva petición:** completar datos del ciudadano (DPI 13 dígitos), título, descripción, prioridad, departamento.
- **Detalle:** consultar historial; **no** cambiar estado (sin permiso API).

### Restricciones
- No accede a Usuarios ni Dashboard.

---

## 3. Jefe de Departamento (JEFE_DEPTO)

### Inicio de sesión
Ejemplo: `jefe_obras` / `jefe123` (requiere seed `npm run seed:jefes`).

### Acciones principales
- **Peticiones:** solo las de su departamento asignado.
- **Detalle:** cambiar estado y agregar comentario de seguimiento.

### Restricciones
- No crea peticiones nuevas.
- No accede a dashboard, usuarios ni listado de departamentos (API 403).

---

## 4. Alcalde / Autoridad (ALCALDE)

### Inicio de sesión
`alcalde` / `alcalde123` → **Dashboard**.

### Acciones principales
- Dashboard e indicadores (igual que admin en reportes).
- Consultar todas las peticiones.
- Registrar nuevas peticiones (`/peticiones/nueva`).
- Cambiar estados y eliminar peticiones.

### Restricciones
- No administra usuarios (solo ADMIN).

---

## Filtros en peticiones

1. Ir a **Peticiones**.
2. Usar campo de búsqueda, select **Estado** y **Prioridad**.
3. Aplicar filtros (botón/buscar según UI en `Peticiones.jsx`).

---

## Seguimiento e historial

1. Abrir una petición desde el listado.
2. En detalle, revisar sección de **historial** (movimientos de estado).
3. Si el rol permite, seleccionar nuevo estado y comentario → guardar.

---

## Solución de problemas frecuentes

| Problema | Acción |
|----------|--------|
| No carga datos | Verificar backend (`/health`) |
| Sesión cerrada sola | Token expirado — volver a login |
| Acceso denegado | Rol sin permiso para esa pantalla |
