# Resultados de pruebas — ejecución local

**Fecha:** 2026-10-15 (UTC)  
**Entorno:** SISTEMA EJECUTADO EN ENTORNO LOCAL  
**Base URL:** http://localhost:5000  
**Fuente:** `resultados_pruebas.json`, `salida_pruebas_terminal.txt`, `salida_e2e_roles.txt`

---

## Resumen script tesis (18 casos)

| Métrica | Valor |
|---------|-------|
| **TOTAL** | 18 |
| **PASS** | 18 |
| **FAIL** | 0 |

---

## Detalle por caso

| ID | Objetivo | Entrada | Esperado | Obtenido | Estado |
|----|----------|---------|----------|----------|--------|
| T01 | Login correcto | admin / admin123 | 200 + token | 200, token presente | PASS |
| T02 | Contraseña incorrecta | admin / wrong | 401 | 401 | PASS |
| T03 | Usuario inexistente | usuario ficticio | 401 | 401 | PASS |
| T04 | Usuario inactivo | crear, desactivar, login | 403 | 403 | PASS |
| T05 | Sin autenticación | GET /peticiones | 401 | 401 | PASS |
| T06 | Rol incorrecto | recepcion → /usuarios | 403 | 403 | PASS |
| T07 | Crear usuario | POST /usuarios | 201 | 201 | PASS |
| T08 | Duplicado | mismo username | 400 | 400 | PASS |
| T09 | Ciudadano nuevo | POST /peticiones | 201 | 201 | PASS |
| T10 | Mismo DPI | segunda petición | 201 reutiliza | 201 | PASS |
| T11 | Registro petición | POST /peticiones | 201 | 201 | PASS |
| T12 | Datos inválidos | DPI/título inválidos | 400 | 400 | PASS |
| T13 | Cambio estado | PUT estado EN_REVISION | 200 | 200 | PASS |
| T14 | Seguimiento | comentario en cambio | OK con T13 | OK | PASS |
| T15 | Historial | GET detalle | historial ≥ 1 | historial ≥ 1 | PASS |
| T16 | Filtros | estado=RECIBIDA | 200 | 200 | PASS |
| T17 | Dashboard | GET /reportes/dashboard | 200 | 200 | PASS |
| T18 | Integridad FK | idDepartamento=99999 | ≥400 | 500 | PASS |

**Nota T18:** La API responde 500 ante violación FK (no hay mensaje amigable específico); la integridad referencial en BD sí rechaza la inserción.

**Nota T10:** El sistema **no** devuelve error por DPI duplicado; reutiliza el ciudadano existente (diseño intencional en `crearPeticion`).

---

## Script e2e-roles (`npm run test:roles`)

**RESULTADO:** TODAS LAS PRUEBAS OK (6 usuarios, múltiples asserts por rol).

Ver log completo en `salida_e2e_roles.txt`.

---

## Observaciones para la tesis

- Primera ejecución del script tesis registró 2 FAIL por expectativas del script (`seguimientos` vs campo real `historial`; idUsuario vs `IdUsuario`). Corregido en `ejecutar_pruebas_tesis.js` sin modificar el sistema.
- Captura sugerida: terminal con salida `TOTAL: 18 PASS: 18 FAIL: 0` → `15_pruebas_terminal.png`.
