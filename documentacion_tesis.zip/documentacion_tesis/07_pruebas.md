# Fase 5 — Plan de pruebas técnicas

## Framework de pruebas unitarias

**NO IMPLEMENTADO** (sin Jest/Mocha/Vitest en el repositorio).

## Scripts de prueba existentes / creados para tesis

| Script | Propósito |
|--------|-----------|
| `backend-muni/scripts/e2e-roles.js` | Prueba API por rol (npm `test:roles`) |
| `documentacion_tesis/ejecutar_pruebas_tesis.js` | 18 casos alineados a requisitos de tesis |

## Precondiciones

1. SQL Server Express con BD `MuniPeticionesJalapa`.
2. Backend en `http://localhost:5000` (`npm start`).
3. Usuarios seed: `admin`, `alcalde`, `recepcion`, jefes (ver `README.md`).
4. `JWT_SECRET` en `.env`.

## Ejecución

```powershell
cd backend-muni
npm.cmd start
# otra terminal:
node ..\documentacion_tesis\ejecutar_pruebas_tesis.js
npm.cmd run test:roles
```

## Casos (T01–T18)

| ID | Objetivo |
|----|----------|
| T01 | Login correcto |
| T02 | Login contraseña incorrecta |
| T03 | Usuario inexistente |
| T04 | Usuario inactivo |
| T05 | Ruta protegida sin token |
| T06 | Rol incorrecto (RECEPCION → /usuarios) |
| T07 | Creación de usuario |
| T08 | Username duplicado |
| T09 | Registro ciudadano vía petición |
| T10 | Reutilización DPI (comportamiento real) |
| T11 | Registro petición |
| T12 | Petición datos inválidos |
| T13 | Cambio de estado |
| T14 | Seguimiento al cambiar estado |
| T15 | Historial en detalle (`historial[]`) |
| T16 | Filtros listado |
| T17 | Dashboard ADMIN |
| T18 | FK departamento inválido |

Resultados detallados: `08_resultados_pruebas.md`, `resultados_pruebas.json`.

## Pruebas manuales UI

Ver `13_lista_capturas.md` y `MANUAL_USUARIO.md`.
