# Capturas pendientes — instrucciones exactas

Generar cada PNG en esta carpeta con el nombre indicado en `../13_lista_capturas.md`.

Prioridad para la defensa:

1. Login + Dashboard (admin) + Listado peticiones + Detalle con historial.
2. Terminal pruebas 18/18.
3. SSMS con resultados de `consultas_evidencia.sql`.

**Demostración:** SISTEMA EJECUTADO EN ENTORNO LOCAL (http://localhost:5173 + SQL Express).
