# Código fuente para anexos de tesis

Fragmentos clave (no copiar archivos completos). Verificar líneas en el repositorio al maquetar.

---

## 1. Autenticación (login JWT)

| Campo | Valor |
|-------|-------|
| **ARCHIVO** | `backend-muni/src/services/auth.service.js` |
| **FUNCIÓN** | `login` |
| **LÍNEAS** | 5–52 (aprox.) |
| **EXPLICACIÓN** | Valida usuario, compara bcrypt, verifica `Activo`, emite JWT con rol e idDepartamento. |

---

## 2. Hash / verificación de contraseña

| Campo | Valor |
|-------|-------|
| **ARCHIVO** | `backend-muni/src/services/auth.service.js` |
| **FUNCIÓN** | `login` → `bcrypt.compare` |
| **LÍNEAS** | 15–17 |
| **EXPLICACIÓN** | Comparación segura contra `PasswordHash`. |

| Campo | Valor |
|-------|-------|
| **ARCHIVO** | `backend-muni/src/services/usuarios.service.js` |
| **FUNCIÓN** | `crearUsuario` |
| **LÍNEAS** | 51–52 (`bcrypt.hash`, SALT_ROUNDS=10) |
| **EXPLICACIÓN** | Almacenamiento de contraseñas nuevas. |

---

## 3. Autorización por roles

| Campo | Valor |
|-------|-------|
| **ARCHIVO** | `backend-muni/src/middlewares/role.middleware.js` |
| **FUNCIÓN** | `authorizeRoles` |
| **LÍNEAS** | 1–21 |
| **EXPLICACIÓN** | Middleware factory que valida `req.user.rol`. |

---

## 4. Protección de rutas (API)

| Campo | Valor |
|-------|-------|
| **ARCHIVO** | `backend-muni/src/middlewares/auth.middleware.js` |
| **FUNCIÓN** | `authenticateJWT` |
| **LÍNEAS** | 3–37 |
| **EXPLICACIÓN** | Extrae Bearer token y verifica JWT. |

| Campo | Valor |
|-------|-------|
| **ARCHIVO** | `backend-muni/src/routes/peticiones.routes.js` |
| **FUNCIÓN** | definición de rutas |
| **LÍNEAS** | 7–13 |
| **EXPLICACIÓN** | JWT + roles por endpoint. |

---

## 5. Protección de rutas (frontend)

| Campo | Valor |
|-------|-------|
| **ARCHIVO** | `frontend-react/src/routes/ProtectedRoute.jsx` |
| **FUNCIÓN** | `ProtectedRoute`, `RoleRoute` |
| **LÍNEAS** | 6–19 |
| **EXPLICACIÓN** | Redirige a login o home si rol no permitido. |

---

## 6. Registro de ciudadano

| Campo | Valor |
|-------|-------|
| **ARCHIVO** | `backend-muni/src/repositories/peticiones.repository.js` |
| **FUNCIÓN** | `createCiudadano` |
| **LÍNEAS** | 13–27 |
| **EXPLICACIÓN** | INSERT parametrizado en `Ciudadano`. |

---

## 7. Creación de petición

| Campo | Valor |
|-------|-------|
| **ARCHIVO** | `backend-muni/src/services/peticiones.service.js` |
| **FUNCIÓN** | `crearPeticion` |
| **LÍNEAS** | 21–78 |
| **EXPLICACIÓN** | Validaciones, transacción, ciudadano, código, petición, seguimiento inicial. |

---

## 8. Generación de código

| Campo | Valor |
|-------|-------|
| **ARCHIVO** | `backend-muni/src/repositories/peticiones.repository.js` |
| **FUNCIÓN** | `generateCodigoPeticion` |
| **LÍNEAS** | 30–49 |
| **EXPLICACIÓN** | Actualiza `SecuenciaCodigo` y forma `JAL-{año}-{correlativo}`. |

---

## 9. Asignación a departamento

| Campo | Valor |
|-------|-------|
| **ARCHIVO** | `backend-muni/src/repositories/peticiones.repository.js` |
| **FUNCIÓN** | `createPeticion` |
| **LÍNEAS** | 52–72 |
| **EXPLICACIÓN** | Inserta `IdDepartamento` en petición. |

---

## 10. Cambio de estado

| Campo | Valor |
|-------|-------|
| **ARCHIVO** | `backend-muni/src/services/peticiones.service.js` |
| **FUNCIÓN** | `cambiarEstadoPeticion` |
| **LÍNEAS** | 81–128 |
| **EXPLICACIÓN** | Reglas por rol/depto, transacción, update + seguimiento. |

---

## 11. Registro de seguimiento

| Campo | Valor |
|-------|-------|
| **ARCHIVO** | `backend-muni/src/repositories/peticiones.repository.js` |
| **FUNCIÓN** | `createSeguimiento` |
| **LÍNEAS** | 77–87 |
| **EXPLICACIÓN** | INSERT en `Seguimiento` con estados y comentario. |

---

## 12. Historial

| Campo | Valor |
|-------|-------|
| **ARCHIVO** | `backend-muni/src/repositories/peticiones.repository.js` |
| **FUNCIÓN** | `getPeticionDetalle` |
| **LÍNEAS** | 276–323 |
| **EXPLICACIÓN** | Consulta seguimientos ordenados; propiedad `historial`. |

---

## 13. Dashboard / reportes

| Campo | Valor |
|-------|-------|
| **ARCHIVO** | `backend-muni/src/routes/reportes.routes.js` |
| **FUNCIÓN** | rutas GET |
| **LÍNEAS** | 7–13 |
| **EXPLICACIÓN** | Solo ADMIN y ALCALDE. |

| Campo | Valor |
|-------|-------|
| **ARCHIVO** | `frontend-react/src/pages/Dashboard.jsx` |
| **FUNCIÓN** | componente página |
| **EXPLICACIÓN** | Consume `/reportes/dashboard` (ver imports y useEffect en archivo). |

---

## 14. Conexión SQL Server

| Campo | Valor |
|-------|-------|
| **ARCHIVO** | `backend-muni/src/config/db.js` |
| **FUNCIÓN** | configuración exportada |
| **LÍNEAS** | 1–57 |
| **EXPLICACIÓN** | Windows Auth local vs SQL Auth nube. |

| Campo | Valor |
|-------|-------|
| **ARCHIVO** | `backend-muni/src/db/pool.js` |
| **FUNCIÓN** | `getPool`, `withPool` |
| **LÍNEAS** | 24–116 |
| **EXPLICACIÓN** | Pool de conexiones y reconexión. |

---

## 15. Consulta parametrizada (ejemplo)

| Campo | Valor |
|-------|-------|
| **ARCHIVO** | `backend-muni/src/repositories/auth.repository.js` |
| **FUNCIÓN** | `findUserByUsername` |
| **LÍNEAS** | 3–20 |
| **EXPLICACIÓN** | `@username` en WHERE. |
