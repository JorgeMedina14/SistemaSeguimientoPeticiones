-- Evidencia SQL Server — Sistema MuniPeticionesJalapa
-- Ejecutar en SSMS conectado a: localhost\SQLEXPRESS
USE MuniPeticionesJalapa;
GO

-- 1. Ciudadanos
SELECT TOP (50)
  IdCiudadano, DPI, Nombres, Apellidos, Telefono, Correo, Activo, FechaRegistro
FROM dbo.Ciudadano
ORDER BY IdCiudadano;
GO

-- 2. Peticiones
SELECT TOP (50)
  IdPeticion, Codigo, IdCiudadano, IdDepartamento, Estado, Prioridad, FechaCreacion, FechaCierre
FROM dbo.Peticion
ORDER BY FechaCreacion DESC;
GO

-- 3. Petición + ciudadano
SELECT
  p.IdPeticion,
  p.Codigo,
  p.Titulo,
  p.Estado,
  c.DPI,
  c.Nombres,
  c.Apellidos
FROM dbo.Peticion p
INNER JOIN dbo.Ciudadano c ON c.IdCiudadano = p.IdCiudadano
ORDER BY p.FechaCreacion DESC;
GO

-- 4. Petición + departamento
SELECT
  p.IdPeticion,
  p.Codigo,
  p.Titulo,
  p.Estado,
  d.Nombre AS Departamento
FROM dbo.Peticion p
INNER JOIN dbo.Departamento d ON d.IdDepartamento = p.IdDepartamento
ORDER BY p.FechaCreacion DESC;
GO

-- 5. Usuarios + roles
SELECT
  u.IdUsuario,
  u.Username,
  u.NombreCompleto,
  u.Rol,
  u.Activo,
  d.Nombre AS Departamento
FROM dbo.Usuario u
LEFT JOIN dbo.Departamento d ON d.IdDepartamento = u.IdDepartamento
ORDER BY u.IdUsuario;
GO

-- 6. Seguimientos
SELECT TOP (100)
  s.IdSeguimiento,
  s.IdPeticion,
  s.EstadoAnterior,
  s.EstadoNuevo,
  s.Comentario,
  s.FechaMovimiento,
  u.Username
FROM dbo.Seguimiento s
LEFT JOIN dbo.Usuario u ON u.IdUsuario = s.IdUsuario
ORDER BY s.FechaMovimiento DESC;
GO

-- 7. Historial completo de una petición (ajustar @IdPeticion)
DECLARE @IdPeticion BIGINT = (SELECT TOP (1) IdPeticion FROM dbo.Peticion ORDER BY FechaCreacion DESC);

SELECT p.*, c.DPI, c.Nombres, c.Apellidos, d.Nombre AS Departamento
FROM dbo.Peticion p
JOIN dbo.Ciudadano c ON c.IdCiudadano = p.IdCiudadano
JOIN dbo.Departamento d ON d.IdDepartamento = p.IdDepartamento
WHERE p.IdPeticion = @IdPeticion;

SELECT s.*
FROM dbo.Seguimiento s
WHERE s.IdPeticion = @IdPeticion
ORDER BY s.FechaMovimiento ASC;
GO

-- 8. Peticiones por estado
SELECT Estado, COUNT(*) AS Total
FROM dbo.Peticion
GROUP BY Estado
ORDER BY Total DESC;
GO

-- 9. Peticiones por departamento
SELECT d.Nombre AS Departamento, COUNT(p.IdPeticion) AS Total
FROM dbo.Departamento d
LEFT JOIN dbo.Peticion p ON p.IdDepartamento = d.IdDepartamento
GROUP BY d.Nombre
ORDER BY Total DESC;
GO

-- 10. Peticiones resueltas (RESUELTA + CERRADA según README)
SELECT IdPeticion, Codigo, Estado, FechaCreacion, FechaCierre
FROM dbo.Peticion
WHERE Estado IN ('RESUELTA', 'CERRADA')
ORDER BY FechaCierre DESC, FechaCreacion DESC;
GO

-- 11. Peticiones pendientes (resto de estados)
SELECT IdPeticion, Codigo, Estado, Prioridad, FechaCreacion
FROM dbo.Peticion
WHERE Estado NOT IN ('RESUELTA', 'CERRADA')
ORDER BY FechaCreacion DESC;
GO

-- 12. Últimos registros creados
SELECT TOP (10) 'Ciudadano' AS Entidad, CAST(IdCiudadano AS VARCHAR(20)) AS Id, FechaRegistro AS Fecha
FROM dbo.Ciudadano
UNION ALL
SELECT TOP (10) 'Peticion', CAST(IdPeticion AS VARCHAR(20)), FechaCreacion
FROM dbo.Peticion
UNION ALL
SELECT TOP (10) 'Seguimiento', CAST(IdSeguimiento AS VARCHAR(20)), FechaMovimiento
FROM dbo.Seguimiento
ORDER BY Fecha DESC;
GO

-- Relaciones (FK del esquema)
SELECT
  fk.name AS FK_Name,
  tp.name AS Tabla,
  cp.name AS Columna,
  tr.name AS Tabla_Referenciada,
  cr.name AS Columna_Referenciada
FROM sys.foreign_keys fk
INNER JOIN sys.foreign_key_columns fkc ON fk.object_id = fkc.constraint_object_id
INNER JOIN sys.tables tp ON fkc.parent_object_id = tp.object_id
INNER JOIN sys.columns cp ON fkc.parent_object_id = cp.object_id AND fkc.parent_column_id = cp.column_id
INNER JOIN sys.tables tr ON fkc.referenced_object_id = tr.object_id
INNER JOIN sys.columns cr ON fkc.referenced_object_id = cr.object_id AND fkc.referenced_column_id = cr.column_id
WHERE tp.schema_id = SCHEMA_ID('dbo')
ORDER BY tp.name, fk.name;
GO
