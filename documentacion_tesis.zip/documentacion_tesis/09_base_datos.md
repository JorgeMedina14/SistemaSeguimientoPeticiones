# Base de datos — resumen para tesis

Documentación completa en repositorio: **`DATABASE.md`** (raíz del proyecto).

## Identificación

| Atributo | Valor |
|----------|-------|
| Motor | Microsoft SQL Server |
| Instancia local documentada | `localhost\SQLEXPRESS` |
| Base de datos | `MuniPeticionesJalapa` |
| Esquema | `dbo` |
| Tablas | 6 |

## Tablas

1. **Ciudadano** — persona que presenta peticiones (DPI único 13 dígitos).
2. **Departamento** — áreas municipales.
3. **Usuario** — cuentas del sistema (rol, hash contraseña).
4. **Peticion** — solicitud con código, estado, prioridad.
5. **Seguimiento** — historial de cambios de estado.
6. **SecuenciaCodigo** — correlativo anual (código visible `JAL-AAAA-NNNNNN` generado en app).

## Relaciones principales

- Peticion → Ciudadano, Departamento, Usuario (creador)
- Seguimiento → Peticion (**ON DELETE CASCADE**), Usuario
- Usuario → Departamento (opcional)

## Estados y roles (CHECK)

- **Estado petición:** RECIBIDA, EN_REVISION, ASIGNADA, EN_PROCESO, RESUELTA, RECHAZADA, CERRADA
- **Prioridad:** BAJA, MEDIA, ALTA
- **Rol usuario:** ADMIN, ALCALDE, JEFE_DEPTO, RECEPCION

## Scripts de evidencia (carpeta tesis)

| Archivo | Uso |
|---------|-----|
| `consultas_evidencia.sql` | SELECT para capturas SSMS |
| `datos_prueba.sql` | Datos sintéticos TESIS-* (sin DROP/TRUNCATE) |

## Importación

Ejecutar en SSMS el script `bdmUNI_importar_SSMS.sql` (referenciado en `DATABASE.md`).

## Vistas / procedimientos

**NO IMPLEMENTADO** en el script de base de datos analizado.
