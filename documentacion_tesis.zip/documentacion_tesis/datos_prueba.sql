-- Datos sintéticos para pruebas de tesis — MuniPeticionesJalapa
-- NO contiene DROP, TRUNCATE ni DELETE masivo.
-- Ejecutar en SSMS: localhost\SQLEXPRESS → USE MuniPeticionesJalapa
-- Re-ejecutable: usa DPI y códigos prefijados TESIS-* con comprobaciones.

USE MuniPeticionesJalapa;
GO

SET NOCOUNT ON;

-- Ciudadanos ficticios (~20)
DECLARE @Ciudadanos TABLE (DPI VARCHAR(13), Nombres NVARCHAR(120), Apellidos NVARCHAR(120), Tel VARCHAR(20));
INSERT INTO @Ciudadanos VALUES
('9000000000001', N'Ana', N'Ficticia Uno', '55550001'),
('9000000000002', N'Luis', N'Ficticio Dos', '55550002'),
('9000000000003', N'Carla', N'Ficticia Tres', '55550003'),
('9000000000004', N'Marco', N'Ficticio Cuatro', '55550004'),
('9000000000005', N'Sofia', N'Ficticia Cinco', '55550005'),
('9000000000006', N'Diego', N'Ficticio Seis', '55550006'),
('9000000000007', N'Elena', N'Ficticia Siete', '55550007'),
('9000000000008', N'Pablo', N'Ficticio Ocho', '55550008'),
('9000000000009', N'Rosa', N'Ficticia Nueve', '55550009'),
('9000000000010', N'Tomas', N'Ficticio Diez', '55550010'),
('9000000000011', N'Lucia', N'Ficticia Once', '55550011'),
('9000000000012', N'Andres', N'Ficticio Doce', '55550012'),
('9000000000013', N'Nora', N'Ficticia Trece', '55550013'),
('9000000000014', N'Felipe', N'Ficticio Catorce', '55550014'),
('9000000000015', N'Gina', N'Ficticia Quince', '55550015'),
('9000000000016', N'Hector', N'Ficticio Dieciséis', '55550016'),
('9000000000017', N'Irene', N'Ficticia Diecisiete', '55550017'),
('9000000000018', N'Julio', N'Ficticio Dieciocho', '55550018'),
('9000000000019', N'Karen', N'Ficticia Diecinueve', '55550019'),
('9000000000020', N'Leo', N'Ficticio Veinte', '55550020');

INSERT INTO dbo.Ciudadano (DPI, Nombres, Apellidos, Telefono, Correo, Direccion, Activo, FechaRegistro)
SELECT c.DPI, c.Nombres, c.Apellidos, c.Tel, NULL, N'Dirección ficticia tesis', 1, SYSDATETIME()
FROM @Ciudadanos c
WHERE NOT EXISTS (SELECT 1 FROM dbo.Ciudadano x WHERE x.DPI = c.DPI);

-- Peticiones sintéticas (~40) usando departamentos existentes 1-5
DECLARE @Estados TABLE (Estado VARCHAR(20));
INSERT INTO @Estados VALUES ('RECIBIDA'),('EN_REVISION'),('ASIGNADA'),('EN_PROCESO'),('RESUELTA'),('RECHAZADA'),('CERRADA');

DECLARE @i INT = 1;
WHILE @i <= 40
BEGIN
  DECLARE @dpi VARCHAR(13) = (SELECT DPI FROM (SELECT DPI, ROW_NUMBER() OVER (ORDER BY DPI) AS rn FROM @Ciudadanos) t WHERE rn = ((@i - 1) % 20) + 1);
  DECLARE @idCiudadano INT = (SELECT IdCiudadano FROM dbo.Ciudadano WHERE DPI = @dpi);
  DECLARE @depto INT = ((@i - 1) % 5) + 1;
  DECLARE @estado VARCHAR(20) = (SELECT Estado FROM (SELECT Estado, ROW_NUMBER() OVER (ORDER BY Estado) rn FROM @Estados) t WHERE rn = ((@i - 1) % 7) + 1);
  DECLARE @prioridad VARCHAR(10) = CASE (@i % 3) WHEN 0 THEN 'ALTA' WHEN 1 THEN 'BAJA' ELSE 'MEDIA' END;
  DECLARE @codigo VARCHAR(25) = CONCAT('TESIS-', YEAR(GETDATE()), '-', RIGHT('000000' + CAST(@i AS VARCHAR(6)), 6));

  IF @idCiudadano IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Peticion WHERE Codigo = @codigo)
  BEGIN
    INSERT INTO dbo.Peticion (Codigo, IdCiudadano, IdDepartamento, CreadoPorUsuarioId, Titulo, Descripcion, Estado, Prioridad, FechaCreacion, FechaCierre)
    VALUES (
      @codigo,
      @idCiudadano,
      @depto,
      2,
      CONCAT(N'Petición sintética #', @i),
      N'Descripción ficticia generada para evidencia de tesis.',
      @estado,
      @prioridad,
      DATEADD(DAY, -@i, SYSDATETIME()),
      CASE WHEN @estado IN ('RESUELTA','CERRADA') THEN DATEADD(DAY, -(@i - 1), SYSDATETIME()) ELSE NULL END
    );

    DECLARE @idPet BIGINT = SCOPE_IDENTITY();
    INSERT INTO dbo.Seguimiento (IdPeticion, IdUsuario, EstadoAnterior, EstadoNuevo, Comentario, FechaMovimiento)
    VALUES (@idPet, 2, NULL, 'RECIBIDA', N'Alta sintética tesis', DATEADD(DAY, -@i, SYSDATETIME()));

    IF @estado <> 'RECIBIDA'
    BEGIN
      INSERT INTO dbo.Seguimiento (IdPeticion, IdUsuario, EstadoAnterior, EstadoNuevo, Comentario, FechaMovimiento)
      VALUES (@idPet, 2, 'RECIBIDA', @estado, N'Cambio sintético de estado', DATEADD(HOUR, -@i, SYSDATETIME()));
    END
  END

  SET @i += 1;
END

PRINT 'Datos sintéticos TESIS-* insertados (si no existían).';
GO
