# Fase 1 — Auditoría completa del proyecto

**Proyecto:** Sistema Web para el Registro, Control y Seguimiento de Peticiones Ciudadanas en una Municipalidad  
**Repositorio analizado:** `PG_Muni` (estado actual del código fuente)

---

## 1. Tecnologías del frontend

| Elemento | Evidencia |
|----------|-----------|
| React | `frontend-react/package.json` — `react`, `react-dom` |
| Vite | `vite`, `@vitejs/plugin-react`, scripts `dev` / `build` |
| React Router | `react-router-dom` — `src/routes/AppRoutes.jsx` |
| Axios | `axios` — `src/api/axiosConfig.js` |
| Lucide React | iconos — dependencia en `package.json` |
| CSS modular por carpetas | `src/styles/*.css` |

**Nota:** Existe documentación histórica (`POSTMAN_GUIA.txt`) orientada a API; el frontend activo del repositorio es **`frontend-react`**, no `frontend-vanilla` (no presente en el árbol actual).

---

## 2. Tecnologías del backend

| Elemento | Evidencia |
|----------|-----------|
| Node.js | `backend-muni/package.json`, `Dockerfile` usa imagen `node:20-bookworm-slim` |
| Express | `express` — `src/app.js`, `src/server.js` |
| mssql | `src/db/pool.js`, repositorios |
| msnodesqlv8 | dependencia **opcional** — `src/db/sql.js` (Windows Auth local) |
| bcrypt | `src/services/auth.service.js`, `usuarios.service.js` |
| jsonwebtoken | autenticación JWT |
| dotenv | variables de entorno |
| helmet, cors, morgan | middleware HTTP |
| swagger-ui-express | `/api-docs` |

---

## 3. Motor de base de datos

- **Microsoft SQL Server**
- Base de datos: **`MuniPeticionesJalapa`**
- Documentación de esquema: `DATABASE.md`, script de referencia `bdmUNI_importar_SSMS.sql` (mencionado en `DATABASE.md`)

---

## 4. Arquitectura utilizada

- **Cliente–servidor**
- **Frontend:** SPA (Single Page Application) React
- **Backend:** API REST JSON con capas:
  - `routes` → `controllers` → `services` → `repositories` → SQL Server
- **Autenticación:** JWT en cabecera `Authorization: Bearer`
- **Producción (opcional):** backend puede servir `frontend-react/dist` (`src/app.js`)

---

## 5. Estructura de carpetas (resumen)

```
PG_Muni/
├── README.md, DATABASE.md, RAILWAY.md, POSTMAN_GUIA.txt
├── Dockerfile, railway.toml
├── backend-muni/src/
│   ├── config/     (db.js, swagger)
│   ├── controllers/
│   ├── services/
│   ├── repositories/
│   ├── routes/
│   ├── middlewares/
│   ├── db/         (pool.js, sql.js)
│   ├── docs/       (openapi.js)
│   ├── scripts/    (e2e-roles.js, seed-jefes-departamento.js)
│   ├── app.js, server.js
├── frontend-react/src/
│   ├── api/, components/, context/, pages/, routes/, styles/, utils/
```

---

## 6. Módulos implementados

| Módulo | Backend | Frontend |
|--------|---------|----------|
| Autenticación | `/auth` | `Login.jsx`, `AuthContext.jsx` |
| Dashboard / reportes | `/reportes/*` | `Dashboard.jsx` |
| Peticiones | `/peticiones` | `Peticiones.jsx`, `PeticionDetalle.jsx` |
| Nueva petición (+ ciudadano) | `POST /peticiones` | `NuevaPeticion.jsx` |
| Usuarios | `/usuarios` | `Usuarios.jsx` |
| Departamentos (catálogo) | `GET /departamentos` | usado en formularios |
| Diagnóstico BD | `GET /db/ping` | NO IMPLEMENTADO en UI (solo API) |
| Health | `GET /health` | NO IMPLEMENTADO en UI |

**NO IMPLEMENTADO como módulo independiente:** CRUD de ciudadanos (el ciudadano se registra/reutiliza al crear petición).

---

## 7. Rutas del frontend (`AppRoutes.jsx`)

| Ruta | Componente | Restricción de rol |
|------|------------|-------------------|
| `/login` | Login | público (solo no autenticados) |
| `/` | redirección | según rol |
| `/dashboard` | Dashboard | ADMIN, ALCALDE |
| `/reportes` | redirige a `/dashboard` | ADMIN, ALCALDE |
| `/peticiones` | Peticiones | todos los roles autenticados |
| `/peticiones/nueva` | NuevaPeticion | RECEPCION, ALCALDE |
| `/peticiones/:id` | PeticionDetalle | todos los roles autenticados |
| `/usuarios` | Usuarios | ADMIN |
| `*` | NotFound | — |

---

## 8. Endpoints del backend

| Método | Ruta | Auth | Roles |
|--------|------|------|-------|
| GET | `/health` | No | — |
| GET | `/` | No | info API o SPA |
| GET | `/db/ping` | JWT | ADMIN |
| POST | `/auth/login` | No | — |
| GET | `/auth/me` | JWT | cualquier autenticado |
| GET | `/peticiones` | JWT | ADMIN, ALCALDE, JEFE_DEPTO, RECEPCION |
| GET | `/peticiones/:id` | JWT | idem |
| POST | `/peticiones` | JWT | RECEPCION, ALCALDE |
| PUT | `/peticiones/:id/estado` | JWT | ADMIN, ALCALDE, JEFE_DEPTO |
| DELETE | `/peticiones/:id` | JWT | ADMIN, ALCALDE |
| GET | `/departamentos` | JWT | ADMIN, RECEPCION, ALCALDE |
| GET | `/reportes/resumen` | JWT | ADMIN, ALCALDE |
| GET | `/reportes/por-departamento` | JWT | ADMIN, ALCALDE |
| GET | `/reportes/tiempos` | JWT | ADMIN, ALCALDE |
| GET | `/reportes/ciudadanos-frecuentes` | JWT | ADMIN, ALCALDE |
| GET | `/reportes/dashboard` | JWT | ADMIN, ALCALDE |
| POST/GET/PUT/PATCH/DELETE | `/usuarios` … | JWT | ADMIN |
| GET | `/test/*` | JWT | solo `NODE_ENV=development` |

Contrato detallado: `backend-muni/src/docs/openapi.js`, Swagger UI `/api-docs`.

---

## 9. Roles existentes

Valores en BD (`CK_Usuario_Rol`) y código:

- `ADMIN`
- `ALCALDE`
- `JEFE_DEPTO`
- `RECEPCION`

---

## 10. Permisos reales por rol

| Acción | ADMIN | ALCALDE | RECEPCION | JEFE_DEPTO |
|--------|-------|---------|-----------|------------|
| Dashboard / reportes API | Sí | Sí | No (403) | No (403) |
| Listar/ver peticiones | Sí | Sí | Sí | Sí (solo su depto en servicio) |
| Crear petición | No* | Sí | Sí | No (403) |
| Cambiar estado | Sí | Sí | No | Sí (solo su depto) |
| Eliminar petición | Sí | Sí | No | No |
| Usuarios CRUD | Sí | No | No | No |
| GET departamentos | Sí | Sí | Sí | No (403) |
| `/db/ping` | Sí | No | No | No |

\* `POST /peticiones` no incluye rol ADMIN en `peticiones.routes.js`.

Filtro departamento JEFE: `peticiones.service.js` (`listarPeticiones`, `obtenerDetallePeticion`, `cambiarEstadoPeticion`).

---

## 11. Entidades / tablas reales (6)

`Ciudadano`, `Departamento`, `Usuario`, `Peticion`, `Seguimiento`, `SecuenciaCodigo` — ver `DATABASE.md`.

---

## 12. Relaciones de base de datos

- `Peticion` → `Ciudadano`, `Departamento`, `Usuario` (creador)
- `Seguimiento` → `Peticion` (ON DELETE CASCADE), `Usuario`
- `Usuario` → `Departamento` (opcional)

---

## 13. Flujo de autenticación

1. `POST /auth/login` con `username` y `password`
2. `auth.repository` busca usuario
3. `bcrypt.compare` contra `PasswordHash`
4. Validación `Activo`
5. `jwt.sign` con payload (`idUsuario`, `rol`, etc.)
6. Frontend guarda `token` y `user` en `localStorage`
7. Axios adjunta `Authorization: Bearer`
8. `GET /auth/me` al cargar app (`AuthContext`)

---

## 14. Flujo de autorización

1. `authenticateJWT` valida token
2. `authorizeRoles(...)` compara `req.user.rol`
3. Frontend: `ProtectedRoute`, `RoleRoute`, `utils/roles.js`

---

## 15. Almacenamiento de contraseñas

- **bcrypt** (`SALT_ROUNDS = 10` en `usuarios.service.js`)
- Solo hash en columna `Usuario.PasswordHash`
- Login: `bcrypt.compare` en `auth.service.js`

---

## 16. Sesión / token

- **JWT** stateless (no hay tabla de sesiones)
- Expiración: `JWT_EXPIRES_IN` (default `8h`)
- Secret: `JWT_SECRET` (requerido en runtime)
- Logout: borra `localStorage` (frontend)

---

## 17. Validaciones implementadas

- **API:** servicios (`peticiones.service.js`, `usuarios.service.js`, `auth.service.js`)
- **BD:** CHECK constraints (DPI 13 dígitos, estados, roles, prioridades, etc.) — `DATABASE.md`
- **Frontend:** formularios en págenes React (validación básica de campos)

---

## 18. Consultas parametrizadas / SQL Injection

- Repositorios usan `pool.request().input(...)` y parámetros `@nombre`
- Ejemplo: `peticiones.repository.js` — `@dpi`, `@idPeticion`, etc.

---

## 19. Manejo de errores

- Controllers: respuestas JSON `{ success: false, message }` con códigos HTTP
- `app.js`: middleware 404 y 500 global
- Pool SQL: reintento en `withPool` ante conexión cerrada (`pool.js`)
- Axios: interceptor 401 → redirige a login

---

## 20. Variables de entorno utilizadas

| Variable | Uso |
|----------|-----|
| `NODE_ENV` | entorno, rutas `/test`, mensajes error |
| `PORT` | puerto backend (default 5000) |
| `DB_SERVER` | instancia SQL |
| `DB_DATABASE` | nombre BD |
| `DB_TRUSTED_CONNECTION` | Windows Auth local |
| `DB_USER`, `DB_PASSWORD` | SQL Auth (Railway/nube) |
| `DB_PORT`, `DB_ENCRYPT`, `DB_TRUST_SERVER_CERTIFICATE` | conexión nube |
| `DB_ODBC_DRIVER`, `DB_CONNECTION_STRING` | ODBC |
| `JWT_SECRET`, `JWT_EXPIRES_IN` | JWT |
| `FRONTEND_DIST` | ruta build frontend en producción |
| `E2E_BASE_URL` | scripts de prueba |
| `VITE_API_URL` | frontend (build/dev) |

Plantilla: `backend-muni/.env.example`

---

## Framework de pruebas automatizadas

- **NO IMPLEMENTADO:** Jest, Mocha, Vitest, Supertest en el proyecto.
- **Sí existen:** `backend-muni/scripts/e2e-roles.js`, `documentacion_tesis/ejecutar_pruebas_tesis.js` (scripts manuales separados).
