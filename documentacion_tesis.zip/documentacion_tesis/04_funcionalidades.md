# Fase 3 — Funcionalidades reales por módulo

## Inicio de sesión

| Campo | Detalle |
|-------|---------|
| **Objetivo** | Autenticar usuario municipal y obtener JWT |
| **Roles** | Todos |
| **Ruta frontend** | `/login` |
| **Endpoints** | `POST /auth/login`, `GET /auth/me` |
| **Tablas** | `Usuario` |
| **Proceso** | Credenciales → bcrypt → JWT → localStorage → redirección según rol |

---

## Dashboard

| Campo | Detalle |
|-------|---------|
| **Objetivo** | Visualizar indicadores y actividad reciente |
| **Roles** | ADMIN, ALCALDE |
| **Ruta frontend** | `/dashboard` |
| **Endpoints** | `GET /reportes/dashboard` (+ resumen, por departamento, tiempos, ciudadanos frecuentes en servicio) |
| **Tablas** | `Peticion`, `Seguimiento`, `Departamento`, `Ciudadano` |
| **Proceso** | Página carga métricas agregadas desde API y muestra tablas/gráficos simples |

---

## Peticiones (listado)

| Campo | Detalle |
|-------|---------|
| **Objetivo** | Consultar peticiones con paginación y filtros |
| **Roles** | ADMIN, ALCALDE, RECEPCION, JEFE_DEPTO (jefe filtrado por departamento) |
| **Ruta frontend** | `/peticiones` |
| **Endpoints** | `GET /peticiones` (query: `page`, `limit`, `estado`, `prioridad`, `departamento`, `fechaInicio`, `fechaFin`, `q`) |
| **Tablas** | `Peticion`, joins ciudadano/departamento |
| **Proceso** | Listado → filtros en UI → API → tabla |

---

## Registro de petición (incluye ciudadano)

| Campo | Detalle |
|-------|---------|
| **Objetivo** | Registrar ciudadano (nuevo o existente por DPI) y crear petición |
| **Roles** | RECEPCION, ALCALDE |
| **Ruta frontend** | `/peticiones/nueva` |
| **Endpoints** | `POST /peticiones`, `GET /departamentos` |
| **Tablas** | `Ciudadano`, `Peticion`, `Seguimiento`, `SecuenciaCodigo` |
| **Proceso** | Formulario → transacción: buscar/insertar ciudadano → generar código → insertar petición → seguimiento inicial RECIBIDA |

**Nota:** No existe módulo “Ciudadanos” independiente en el menú.

---

## Detalle, estados, seguimiento e historial

| Campo | Detalle |
|-------|---------|
| **Objetivo** | Ver detalle, cambiar estado con comentario, ver historial de seguimientos |
| **Roles** | Ver: todos autenticados (jefe solo su depto). Cambiar estado: ADMIN, ALCALDE, JEFE_DEPTO |
| **Ruta frontend** | `/peticiones/:id` |
| **Endpoints** | `GET /peticiones/:id`, `PUT /peticiones/:id/estado` |
| **Tablas** | `Peticion`, `Seguimiento`, `Usuario` |
| **Proceso** | Detalle incluye array `seguimientos`; cambio de estado inserta fila en `Seguimiento` y actualiza `Peticion.Estado` |

---

## Estados y prioridades

| Campo | Detalle |
|-------|---------|
| **Objetivo** | Clasificar ciclo de vida y urgencia |
| **Roles** | Consulta: todos; cambio estado: ver arriba |
| **Ruta frontend** | Filtros en `/peticiones`; selector en detalle |
| **Endpoints** | Filtro `estado`/`prioridad` en GET; PUT estado |
| **Tablas** | `Peticion`, CHECK constraints |
| **Valores** | Estados: RECIBIDA, EN_REVISION, ASIGNADA, EN_PROCESO, RESUELTA, RECHAZADA, CERRADA. Prioridad: BAJA, MEDIA, ALTA |

---

## Departamentos

| Campo | Detalle |
|-------|---------|
| **Objetivo** | Catálogo para asignar peticiones |
| **Roles API** | ADMIN, RECEPCION, ALCALDE |
| **Ruta frontend** | NO hay página dedicada; select en Nueva petición |
| **Endpoints** | `GET /departamentos` |
| **Tablas** | `Departamento` |
| **Proceso** | Lista departamentos activos para combo |

---

## Usuarios y roles

| Campo | Detalle |
|-------|---------|
| **Objetivo** | Administrar cuentas del sistema |
| **Roles** | ADMIN |
| **Ruta frontend** | `/usuarios` |
| **Endpoints** | `POST/GET/PUT/PATCH/DELETE /usuarios`, `PATCH .../activo`, `PATCH .../password` |
| **Tablas** | `Usuario`, `Departamento` |
| **Proceso** | CRUD con validaciones (username único, un alcalde activo, jefe requiere departamento) |

---

## Reportes

| Campo | Detalle |
|-------|---------|
| **Objetivo** | Indicadores para autoridad municipal |
| **Roles** | ADMIN, ALCALDE |
| **Ruta frontend** | Integrado en `/dashboard` ( `/reportes` redirige ) |
| **Endpoints** | `/reportes/*` |
| **Tablas** | Agregaciones sobre `Peticion`, `Seguimiento`, `Ciudadano` |
| **Proceso** | Servicio `reportes.service.js` consolida datos para dashboard |

---

## Eliminar petición

| Campo | Detalle |
|-------|---------|
| **Objetivo** | Eliminar registro (y seguimientos en cascada) |
| **Roles** | ADMIN, ALCALDE |
| **Ruta frontend** | NO DETERMINADO si hay botón en UI (API sí existe) |
| **Endpoints** | `DELETE /peticiones/:id` |
| **Tablas** | `Peticion`, `Seguimiento` (CASCADE) |

---

## Diagnóstico BD

| Campo | Detalle |
|-------|---------|
| **Objetivo** | Ping SQL |
| **Roles** | ADMIN |
| **Endpoints** | `GET /db/ping` |
| **UI** | NO IMPLEMENTADO |
