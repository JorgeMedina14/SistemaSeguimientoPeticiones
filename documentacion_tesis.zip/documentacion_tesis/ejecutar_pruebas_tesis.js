/**
 * Pruebas técnicas para documentación de tesis (solo lectura/ejecución API).
 * No modifica el código del sistema.
 * Uso (backend en marcha):
 *   cd backend-muni
 *   node ../documentacion_tesis/ejecutar_pruebas_tesis.js
 */
const path = require('path');
try {
  require(path.join(__dirname, '../backend-muni/node_modules/dotenv')).config({
    path: path.join(__dirname, '../backend-muni/.env')
  });
} catch {
  // dotenv opcional si se ejecuta con variables ya cargadas
}

const BASE = process.env.E2E_BASE_URL || 'http://localhost:5000';
const fs = require('fs');

const results = [];
let counter = 0;

function record(id, objetivo, entrada, esperado, obtenido, pass) {
  counter += 1;
  results.push({ id, objetivo, entrada, esperado, obtenido, estado: pass ? 'PASS' : 'FAIL' });
}

async function api(method, urlPath, { token, body } = {}) {
  const res = await fetch(`${BASE}${urlPath}`, {
    method,
    cache: 'no-store',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {})
    },
    body: body !== undefined ? JSON.stringify(body) : undefined
  });
  const data = await res.json().catch(() => null);
  return { status: res.status, data };
}

async function login(username, password) {
  return api('POST', '/auth/login', { body: { username, password } });
}

(async () => {
  const health = await api('GET', '/health');
  if (health.status !== 200) {
    console.error('Backend no disponible en', BASE);
    process.exit(2);
  }

  // T01 Login correcto
  const okLogin = await login('admin', 'admin123');
  record(
    'T01',
    'Login correcto',
    'admin / admin123',
    'HTTP 200 y token JWT',
    `HTTP ${okLogin.status}${okLogin.data?.data?.token ? ', token presente' : ', sin token'}`,
    okLogin.status === 200 && Boolean(okLogin.data?.data?.token)
  );
  const adminToken = okLogin.data?.data?.token;

  // T02 Contraseña incorrecta
  const badPass = await login('admin', 'wrong');
  record(
    'T02',
    'Login con contraseña incorrecta',
    'admin / wrong',
    'HTTP 401',
    `HTTP ${badPass.status}`,
    badPass.status === 401
  );

  // T03 Usuario inexistente
  const noUser = await login('usuario_que_no_existe_xyz', 'x');
  record(
    'T03',
    'Usuario inexistente',
    'usuario_que_no_existe_xyz',
    'HTTP 401',
    `HTTP ${noUser.status}`,
    noUser.status === 401
  );

  // T04 Usuario inactivo — depende de datos; intento con usuario creado inactivo
  let t04Pass = false;
  let t04Detail = 'NO DETERMINADO (requiere usuario inactivo en BD)';
  if (adminToken) {
    const uname = `inact_${Date.now().toString().slice(-8)}`;
    const create = await api('POST', '/usuarios', {
      token: adminToken,
      body: {
        username: uname,
        password: 'test1234',
        nombreCompleto: 'Usuario Inactivo Prueba',
        rol: 'RECEPCION'
      }
    });
    const createdId = create.data?.data?.idUsuario ?? create.data?.data?.IdUsuario;
    if (create.status === 201 && createdId) {
      const id = createdId;
      await api('PATCH', `/usuarios/${id}/activo`, { token: adminToken, body: { activo: false } });
      const inactLogin = await login(uname, 'test1234');
      t04Pass = inactLogin.status === 403;
      t04Detail = `HTTP ${inactLogin.status} (usuario ${uname} desactivado)`;
      await api('DELETE', `/usuarios/${id}`, { token: adminToken });
    }
  }
  record('T04', 'Usuario inactivo', 'login tras PATCH activo=false', 'HTTP 403', t04Detail, t04Pass);

  // T05 Ruta protegida sin token
  const noAuth = await api('GET', '/peticiones');
  record(
    'T05',
    'Ruta protegida sin autenticación',
    'GET /peticiones sin Authorization',
    'HTTP 401',
    `HTTP ${noAuth.status}`,
    noAuth.status === 401
  );

  // T06 Rol incorrecto
  const recep = await login('recepcion', 'recepcion123');
  const recepToken = recep.data?.data?.token;
  const forbidden = recepToken
    ? await api('GET', '/usuarios', { token: recepToken })
    : { status: 0 };
  record(
    'T06',
    'Usuario con rol incorrecto',
    'RECEPCION → GET /usuarios',
    'HTTP 403',
    `HTTP ${forbidden.status}`,
    forbidden.status === 403
  );

  // T07 Creación de usuario
  const newU = `tesis_${Date.now().toString().slice(-7)}`;
  const createUser = adminToken
    ? await api('POST', '/usuarios', {
        token: adminToken,
        body: {
          username: newU,
          password: 'test1234',
          nombreCompleto: 'Prueba Tesis',
          rol: 'RECEPCION'
        }
      })
    : { status: 0 };
  record(
    'T07',
    'Creación de usuario',
    `POST /usuarios username=${newU}`,
    'HTTP 201',
    `HTTP ${createUser.status}`,
    createUser.status === 201
  );

  // T08 Usuario duplicado
  const dup = adminToken
    ? await api('POST', '/usuarios', {
        token: adminToken,
        body: {
          username: newU,
          password: 'test1234',
          nombreCompleto: 'Duplicado',
          rol: 'RECEPCION'
        }
      })
    : { status: 0 };
  record(
    'T08',
    'Usuario duplicado',
    `POST /usuarios username=${newU} repetido`,
    'HTTP 400',
    `HTTP ${dup.status}`,
    dup.status === 400
  );
  if (createUser.data?.data?.idUsuario && adminToken) {
    await api('DELETE', `/usuarios/${createUser.data.data.idUsuario}`, { token: adminToken });
  }

  // T09 Registro ciudadano (vía petición)
  const dpiNew = `9${String(Date.now()).slice(-12)}`;
  const recepLogin = recepToken || (await login('recepcion', 'recepcion123')).data?.data?.token;
  const petCreate = recepLogin
    ? await api('POST', '/peticiones', {
        token: recepLogin,
        body: {
          ciudadano: {
            dpi: dpiNew,
            nombres: 'Sintetico',
            apellidos: 'Prueba Tesis',
            telefono: '55551234',
            correo: null,
            direccion: 'Zona prueba'
          },
          peticion: {
            titulo: 'Peticion prueba tesis',
            descripcion: 'Descripcion de prueba automatizada',
            prioridad: 'MEDIA'
          },
          idDepartamento: 2
        }
      })
    : { status: 0 };
  record(
    'T09',
    'Registro de ciudadano',
    `POST /peticiones DPI nuevo ${dpiNew}`,
    'HTTP 201',
    `HTTP ${petCreate.status}`,
    petCreate.status === 201
  );
  const idPeticion = petCreate.data?.data?.idPeticion;

  // T10 DPI duplicado — reutiliza ciudadano existente (comportamiento real)
  const petDup = recepLogin
    ? await api('POST', '/peticiones', {
        token: recepLogin,
        body: {
          ciudadano: {
            dpi: dpiNew,
            nombres: 'Otro',
            apellidos: 'Nombre',
            telefono: null,
            correo: null,
            direccion: null
          },
          peticion: {
            titulo: 'Segunda peticion mismo DPI',
            descripcion: 'Debe reutilizar ciudadano',
            prioridad: 'BAJA'
          },
          idDepartamento: 2
        }
      })
    : { status: 0 };
  record(
    'T10',
    'DPI duplicado',
    `mismo DPI ${dpiNew}`,
    'HTTP 201 reutilizando ciudadano (no error de duplicado en API)',
    `HTTP ${petDup.status}`,
    petDup.status === 201
  );

  // T11 Registro petición — cubierto en T09
  record(
    'T11',
    'Registro de petición',
    'POST /peticiones',
    'HTTP 201',
    `HTTP ${petCreate.status}`,
    petCreate.status === 201
  );

  // T12 Sin datos obligatorios
  const badPet = recepLogin
    ? await api('POST', '/peticiones', {
        token: recepLogin,
        body: { ciudadano: { dpi: '123' }, peticion: {}, idDepartamento: 2 }
      })
    : { status: 0 };
  record(
    'T12',
    'Petición sin datos obligatorios',
    'DPI inválido y sin título/descripcion',
    'HTTP 400',
    `HTTP ${badPet.status}`,
    badPet.status === 400
  );

  // T13 Cambio de estado
  const alcalde = await login('alcalde', 'alcalde123');
  const alcaldeToken = alcalde.data?.data?.token;
  let t13 = { status: 0 };
  if (idPeticion && alcaldeToken) {
    t13 = await api('PUT', `/peticiones/${idPeticion}/estado`, {
      token: alcaldeToken,
      body: { estadoNuevo: 'EN_REVISION', comentario: 'Prueba tesis' }
    });
  }
  record(
    'T13',
    'Cambio de estado',
    `PUT /peticiones/${idPeticion || '?'}/estado → EN_REVISION`,
    'HTTP 200',
    `HTTP ${t13.status}`,
    t13.status === 200
  );

  // T14 Seguimiento — implícito en cambio de estado
  record(
    'T14',
    'Registro de seguimiento',
    'Cambio de estado con comentario',
    'Seguimiento insertado (HTTP 200 en T13)',
    t13.status === 200 ? 'Asociado a T13 OK' : 'No ejecutado',
    t13.status === 200
  );

  // T15 Historial
  const detalle = idPeticion && recepLogin
    ? await api('GET', `/peticiones/${idPeticion}`, { token: recepLogin })
    : { status: 0, data: null };
  const hist = detalle.data?.data?.historial ?? detalle.data?.data?.seguimientos ?? [];
  const segCount = hist.length ?? 0;
  record(
    'T15',
    'Consulta de historial',
    `GET /peticiones/${idPeticion || '?'}`,
    'HTTP 200 y array historial >= 1',
    `HTTP ${detalle.status}, historial=${segCount}`,
    detalle.status === 200 && segCount >= 1
  );

  // T16 Filtros
  const filt = recepLogin
    ? await api('GET', '/peticiones?estado=RECIBIDA&limit=5', { token: recepLogin })
    : { status: 0 };
  record(
    'T16',
    'Filtros',
    'GET /peticiones?estado=RECIBIDA',
    'HTTP 200',
    `HTTP ${filt.status}`,
    filt.status === 200
  );

  // T17 Dashboard
  const dash = adminToken
    ? await api('GET', '/reportes/dashboard', { token: adminToken })
    : { status: 0 };
  record(
    'T17',
    'Dashboard',
    'GET /reportes/dashboard como ADMIN',
    'HTTP 200',
    `HTTP ${dash.status}`,
    dash.status === 200
  );

  // T18 Integridad referencial — departamento inexistente
  const fkTest = recepLogin
    ? await api('POST', '/peticiones', {
        token: recepLogin,
        body: {
          ciudadano: {
            dpi: `8${String(Date.now()).slice(-12)}`,
            nombres: 'FK',
            apellidos: 'Test',
            telefono: null,
            correo: null,
            direccion: null
          },
          peticion: {
            titulo: 'FK invalida',
            descripcion: 'Departamento no existe',
            prioridad: 'MEDIA'
          },
          idDepartamento: 99999
        }
      })
    : { status: 0 };
  record(
    'T18',
    'Integridad referencial',
    'idDepartamento=99999',
    'HTTP 4xx/5xx (rechazo por FK)',
    `HTTP ${fkTest.status}`,
    fkTest.status >= 400
  );

  const pass = results.filter((r) => r.estado === 'PASS').length;
  const fail = results.filter((r) => r.estado === 'FAIL').length;
  const summary = { total: results.length, pass, fail, base: BASE, fecha: new Date().toISOString(), results };

  const outJson = path.join(__dirname, 'resultados_pruebas.json');
  fs.writeFileSync(outJson, JSON.stringify(summary, null, 2), 'utf8');

  console.log('TOTAL:', summary.total, 'PASS:', pass, 'FAIL:', fail);
  results.forEach((r) => console.log(`${r.estado} ${r.id} ${r.objetivo}`));
  process.exit(fail > 0 ? 1 : 0);
})();
